* test machine: csel-kh1262-18
* date: 04/08/24
* name: Gresham Basic, Elaine Nguyen, Hilton Nguyen
* x500: basic009, nguy4546, nguy4798

• Your and your partners' contributions
    Equal contributions, worked together through all parts

• How to compile the program
- run "make" to compile everything
- run "./tlist foo.txt 3" to run the thread where "foot.txt" can be replaced with any 
file name to test and "3" can be replaced with n number of threads.

• The purpose of your program

The purpose of the program is to implement a multi-threaded program that reads lines from 
a file concurrently using multiple threads and insert them into a linked list. Elements in the program need to be synchronized to ensure that the program works correctly. Error handling is implemented as well to manage potential issues during file I/O, thread creation, and synchronization.

• What exactly your program does

The program takes two command-line arguments: the name of a file and the number of threads to use. 
 Each thread independently reads the lines from the file, creates nodes containing information about the line number, content, and sequence number, and inserts them into the linked list. Once all lines are inserted, the program traverses the linked list and outputs the sequence number, line number, and content of each node.

        
• Any assumptions outside this document (If you have any)
    None.