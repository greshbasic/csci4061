#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "linked_list.h"

//global line-number counter to be sync'ed.
int line_ctr = 0;

//initialization of mutex locks
pthread_mutex_t line_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t list_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t seq_lock = PTHREAD_MUTEX_INITIALIZER;
//at least two mutex locks should be used

void* process_file(void *param) {
    char *fname = (char*)param;
    char *line;
    int current_line;
    
    while (1) {
        // Synchronize access to line_ctr
        pthread_mutex_lock(&line_lock);
        int current_line = line_ctr;
        line_ctr += 1;
        pthread_mutex_unlock(&line_lock);

        // Read line
        line = read_line(fname, current_line);
        
        // If there's no more lines, break the loop
        if (line == NULL) {
            break;
        }
        
        // Create node
        node *new_node = create_node(current_line, line);
        
        // Insert node into linked list
        pthread_mutex_lock(&list_lock);
        insert(&head, new_node);
        pthread_mutex_unlock(&list_lock);

        // Print line number and content
		printf("%d, %d, %s", new_node->line_no, new_node->seq_no - 1, new_node->content); // Print line number and content
    }
    pthread_exit(NULL);
}
int main(int argc, char* argv[])
{
	FILE* in_ptr;
	int threads;
	char *filename = NULL;

	if (argc != 3) {
		printf("Incorrect arg count. Enter file name and thread count\n");
		exit(EXIT_FAILURE);
	}
	threads = atoi(argv[2]);
	if (threads < 1 || threads > 16) {
		printf("Incorrect number of threads. Enter between 1 and 16\n");
		exit(EXIT_FAILURE);
	}

    // Initialize the linked list head
    head = NULL;

    // Create an array to hold thread IDs
    pthread_t thread_ids[threads];

    // Get filename from command line argument
    filename = argv[1];

    // Create threads
    for (int i = 0; i < threads; i++) {
        if (pthread_create(&thread_ids[i], NULL, process_file, (void*)filename) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    // Join threads
    for (int i = 0; i < threads; i++) {
        if (pthread_join(thread_ids[i], NULL) != 0) {
            perror("pthread_join");
            exit(EXIT_FAILURE);
        }
    }

    // Clean up resources and exit
    pthread_mutex_destroy(&line_lock);
    pthread_mutex_destroy(&list_lock);
    return 0;
}
