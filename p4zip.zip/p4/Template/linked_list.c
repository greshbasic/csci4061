#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pthread.h"
#include "linked_list.h"

// initialize head
node *head = NULL;

// sequence counter
int seq_ctr = 0;

//Read the file on a line by line basis
char* read_line(char* fname, int line_no) {
	FILE *file = fopen(fname, "r");
    if (!file) {
        perror("Failed to open file");
        return NULL;
    }

	char *line = malloc(LINE_SIZE);
    if (!line) {
        perror("Failed to allocate memory");
        fclose(file);
        return NULL;
    }

	int count = 0;
    while (fgets(line, LINE_SIZE, file) != NULL) {
        if (count == line_no) {
            fclose(file);
            return line;
        }
        count += 1;
    }

    free(line);
    fclose(file);
	
} 

//traverse the linked list
void traversal(node *head) {
	while (head != NULL) {
		printf("%d, %d, %s\n", head->seq_no, head->line_no, head->content);
		head = head->next;
	}
}

// insert the node into the linked list
void insert(node **phead, node *newnode) {
	while (*phead != NULL) {
		node* next_node = (*phead)->next;
		phead = &next_node;
	}
	*phead = newnode;
}

//create a new node structure
node* create_node(int line_no, char *line) {
	node *newnode = (node*) malloc(sizeof(node));

	seq_ctr += 1;
	newnode->seq_no = seq_ctr;

	newnode->line_no = line_no;

	newnode->content = (char*) malloc(strlen(line) + 1);
	strcpy(newnode->content, line);

	newnode->next = NULL;

	return newnode;
}